This is your group repo for your final project for COGS108.

This repository is private, and is only visible to the course instructors and your group mates; it is not visible to anyone else.

This repository will be frozen on the final project due date: 11:59pm on Wednesday, June 10th. No further changes can be made after that time.

Your project proposal and final project will be graded based solely on the corresponding project notebook in this repository.

For each due date, make sure you have a notebook present in this repository by each due date with the following name (where XX is replaced by your group number):

- 'ProjectProposal_groupXX.ipynb'
- 'FinalProject_groupXX.ipynb'
